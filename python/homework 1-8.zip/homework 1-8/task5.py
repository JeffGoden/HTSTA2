x= int(input("Enter 1 number"))
y= int(input("Enter a 2nd number"))

print(x is y)

