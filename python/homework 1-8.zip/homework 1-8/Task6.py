Studend_list= ["Li", "Dominik" , "Mustafa", "Tom"]

if "Tom" in Studend_list:
    print("Tim is in this list")
else:
    print("Tim is not there")

if "Tim" not in Studend_list:
    print("Tim is not there")
else:
    print("Tim is in this list")