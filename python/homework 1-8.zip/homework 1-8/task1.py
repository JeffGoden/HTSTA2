school= "3TPIFI"
firstname= "Jeff"

print("Hello, its me,",firstname,"from the",school)