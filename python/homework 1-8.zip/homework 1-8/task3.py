number1= int(input("Enter 1 number"))
number2= int(input("Enter a 2nd number"))

if(number1 == number2):
    print("Its equal")
else:
    print("Its notr equal")
if(number1!= number2):
    print("Its not equal")
else:
    print("its equal")
if(number1>number2):
    print("number 1 is greater than number 2")
else:
    print("number 1 is smaller than number 2")
if(number1<number2):
    print("number 1 is smaller than number 2")
else:
    print("number 1 is greater than number 2")
if(number1>=number2):
    print("number 1 is greater or equal number 2")
else:
    print("number 1 is smaller or equal number 2")
if(number1<=number2):
    print("number 1 is smaller or equal number 2")
else:
    print("number 1 is greater or equal number 2")