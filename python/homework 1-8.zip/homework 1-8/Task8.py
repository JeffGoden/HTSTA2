number1= 25
number2= 30
number1,number2=number2, number1
print(number1,number2)