number1= 1
number2= 0
print(number1 & number2)
print(number1 | number2)
print(number1 ^ number2)
print(number1 ~ number2)
print(number1 << number2)
print(number1 >> number2)