a= int(input("Give me a number "))
b= int(input("Give me a number "))

x= -(b/a)

if a== 0:
    print("please dont put 0")
print(x)