gender= input("What is your Gender? Put for masculin M and for Female F ")
name= input("What is you Name?")
if gender== "M":
    print("Hello, Mr.",name)

elif gender== "m":
    print("Hello, Mr.",name)

elif gender == "F":
    print("Good day, Mrs",name)

elif gender == "f":
    print("Good day, Mrs",name)