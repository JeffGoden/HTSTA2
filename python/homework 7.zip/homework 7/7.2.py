a= int(input("Give me a number "))
b= int(input("Give me a number "))

highest= max(a,b)
print(highest)