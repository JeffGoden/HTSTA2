a= int(input("Give me a number "))
b= int(input("Give me a number "))
cal= a/b
if b == 0:
    print("Dont divide by zero")

print(cal)