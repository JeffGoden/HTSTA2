var currentBoxColor= "redbox";
var number= 1;
function box()
{
    let addBox = '<div class="boxes '+ currentBoxColor +'">' + number +' </div>';
    number++;
    if(currentBoxColor== "redbox")
    {
        currentBoxColor="bluebox";
    }
    else
    if(currentBoxColor== "bluebox")
    {
        currentBoxColor="greenbox";
    }
    else
    if(currentBoxColor== "greenbox")
    {
        currentBoxColor="redbox";
    }
    document.getElementById("boxbody").innerHTML+=addBox;
}